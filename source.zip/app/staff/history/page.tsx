import StaffHistoryTab from "../components/history/StaffHistoryTab";

export default function HistoryPage() {
    return <StaffHistoryTab />;
}
