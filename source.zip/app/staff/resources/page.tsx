import ResourcesTab from "../components/ResourcesTab";

export default function ResourcesPage() {
    return <ResourcesTab />;
}
