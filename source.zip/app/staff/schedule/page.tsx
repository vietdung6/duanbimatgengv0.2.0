import StaffScheduleTab from "../components/schedule/StaffScheduleTab";

export default function SchedulePage() {
    return <StaffScheduleTab />;
}
