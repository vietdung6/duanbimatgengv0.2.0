import ViewingPartyManagementTab from "../components/ViewingPartyManagementTab";

export default function ViewingPartyPage() {
    return <ViewingPartyManagementTab />;
}
