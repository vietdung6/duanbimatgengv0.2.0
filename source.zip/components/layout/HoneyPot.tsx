"use client";

export default function HoneyPot() {
    return (
        <div
            dangerouslySetInnerHTML={{
                __html: `
<!-- 
  /$$$$$$  /$$$$$$$$ /$$   /$$       /$$$$$$ 
 /$$__  $$| $$_____/| $$$ | $$      /$$__  $$
| $$  \\__/| $$      | $$$$| $$     | $$  \\__/
| $$ /$$$$| $$$$$   | $$ $$ $$     | $$ /$$$$
| $$|_  $$| $$__/   | $$  $$$$     | $$|_  $$
| $$  \\ $$| $$      | $$\\  $$$     | $$  \\ $$
|  $$$$$$/| $$$$$$$$| $$ \\  $$     |  $$$$$$/
 \\______/ |________/|__/  \\__/      \\______/ 

  ================================================
  🛑 SYSTEM LOG: CLASSIFIED AGENT PROFILE
  ================================================
  
  [MISSION PROFILE]
    > Agent Code: TRIPLE_WORLDS(Gián điệp từ T1)
        > Mission: "Infiltrate & Sabotage Gen.G"
  > Start Date: 2026-01-01
  
  [OPERATION LOGS]
  > Ngày 1: Xâm nhập thành công. Đã cấp quyền Admin.
  > Ngày 7: Đang tìm lỗ hỏng của Website.
  > Ngày 14: ERROR 404. Không tìm thấy gì, chỉ thấy Chovy đang farm lính.   
  > Ngày 30: Vô tình cổ vũ GenG chiến thắng...Cảm giác thật lạ...
  > Ngày 60: NHIỆM VỤ THẤT BẠI, TÔI KHÔNG THỂ PHẢN BỘI HỌ
  
  [SECURITY ALERT]
  > TRAP DETECTED: /super-secret-credentials.js
    > ACTION: Đừng mở, đó là một cái bẫy (just me bro)

  [CURRENT STATUS]
  > AGENT COMPROMISED / ASSIMILATED.
  > LOYALTY: 100 % GEN.G
  > QUOTE: "Once a GenCon, always a GenCon."
  
  [SECRET NOTE]
  If you are reading this, join the Tiger Nation now.
  We have Chovy(and absolute domination in LCK).
  =============================================
   Property of Gen.G Fandom Engineering Team























  























  



































































  ================================================
  ================================================
  Are you a Dev looking for the truth? 
  Check out: /dev-confession.html
  (Seriously, go read it.)
  ================================================
  
  ------------------------------------------------
  Property of Gen.G Fandom Engineering Team
-->
`,
            }}
            style={{ display: "none" }}
        />
    );
}
