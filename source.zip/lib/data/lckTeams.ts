export const LCK_TEAMS = [
  {
    name: "T1",
    logo: "https://am-a.akamaihd.net/image?resize=1920:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1726801573959_539px-T1_2019_full_allmode.png"
  },
  {
    name: "Hanwha Life Esports",
    shortName: "HLE",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1631819564399_hle-2021-worlds.png"
  },
  {
    name: "KT Rolster",
    shortName: "KT",
    logo: "https://am-a.akamaihd.net/image?resize=1920:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2Fkt_darkbackground.png"
  },
  {
    name: "Nongshim RedForce",
    shortName: "NS",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2FNSFullonDark.png"
  },
  {
    name: "Dplus KIA",
    shortName: "DK",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1673260049703_DPlusKIALOGO11.png"
  },
  {
    name: "DRX",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1672910733664_01.Basic_W.png"
  },
  {
    name: "OKSavingsBank BRION",
    shortName: "BRO",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1716454325887_Nowyprojekt.png"
  },
  {
    name: "BNK FearX",
    shortName: "BFX",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1734691810721_BFXfullcolorfordarkbg.png"
  },
  {
    name: "Kwangdong Freecs",
    shortName: "KDF",
    logo: "https://am-a.akamaihd.net/image?resize=64:&f=http%3A%2F%2Fstatic.lolesports.com%2Fteams%2F1735904500256_DN_Freecslogo_profile.webp"
  }
];
