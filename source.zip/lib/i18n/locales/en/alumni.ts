export const alumni = {
  badge: "FORMER PLAYERS",
  title: "ALUMNI",
  subtitle: "The players who built our legacy. From Samsung to Gen.G, honoring those who wore our colors.",
  yearsActive: "Years Active",
  achievements: "Achievements",
  worldChampion: "World Champion",
};
