export const fanZone = {
  badge: "FAN ZONE",
  title: "FAN ZONE",
  description: "Your ultimate destination for Gen.G fan activities. Play games, earn points, and prove your fandom!",
};
