export const legends = {
  badge: "HALL OF LEGENDS",
  title: "LEGENDS",
  subtitle: "The greatest players in our history. World Champions, MVPs, and icons who defined an era.",
  mvp: "MVP",
  allTime: "All-Time Great",
  legacy: "Legacy",
};
