export const nav = {
  team: "TEAM",
  achievements: "ACHIEVEMENTS",
  schedule: "SCHEDULE",
  gallery: "GALLERY",
  fanZone: "FAN ZONE",
  enterShrine: "ENTER CHURCH",
  profile: "Profile",
};
