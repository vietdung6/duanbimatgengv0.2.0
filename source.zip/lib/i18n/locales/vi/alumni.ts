export const alumni = {
  badge: "CỰU TUYỂN THỦ",
  title: "CỰU TUYỂN THỦ",
  subtitle: "Những tuyển thủ đã xây dựng nên di sản. Từ Samsung đến Gen.G, vinh danh những người đã khoác áo chúng ta.",
  yearsActive: "Năm thi đấu",
  achievements: "Thành tích",
  worldChampion: "Vô địch Thế giới",
};
