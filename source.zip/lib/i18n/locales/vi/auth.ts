export const auth = {
  title: "ĐĂNG NHẬP FAN",
  subtitle: "Đăng nhập để tham gia viewing party, dự đoán tỉ số và mở khoá tính năng cho fan Gen.G.",
  emailOrUsername: "Email hoặc Username",
  password: "Mật khẩu",
  submit: "Đăng nhập",
  login: "Đăng nhập",
  logout: "Đăng xuất",
  loading: "Đang đăng nhập...",
  errorGeneric: "Đăng nhập thất bại. Vui lòng kiểm tra lại thông tin.",
  backToHome: "Về trang chủ",
};
