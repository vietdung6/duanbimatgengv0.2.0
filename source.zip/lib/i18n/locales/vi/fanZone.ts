export const fanZone = {
  badge: "FAN ZONE",
  title: "FAN ZONE",
  description: "Điểm đến tối thượng cho các hoạt động fan Gen.G. Chơi game, kiếm điểm và chứng minh bạn là fan thực sự!",
};
