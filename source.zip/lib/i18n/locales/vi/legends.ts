export const legends = {
  badge: "ĐIỆN VINH DANH",
  title: "HUYỀN THOẠI",
  subtitle: "Những tuyển thủ vĩ đại nhất trong lịch sử. Vô địch Thế giới, MVP, và những biểu tượng định hình thời đại.",
  mvp: "MVP",
  allTime: "Huyền Thoại",
  legacy: "Di Sản",
};
