export const nav = {
  team: "ĐỘI HÌNH",
  achievements: "THÀNH TÍCH",
  schedule: "LỊCH THI ĐẤU",
  gallery: "THƯ VIỆN",
  fanZone: "FAN ZONE",
  enterShrine: "VÀO ĐỀN THỜ",
  profile: "Hồ sơ ",
};
