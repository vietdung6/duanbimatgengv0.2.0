/*
      |\      _,,,---,,_
ZZZzz /,`.-'`'    -.  ;-;;,_
     |,4-  ) )-,_. ,\ (  `'-'
    '---''(_/--'  `-'\_)
    
    SYSTEM: ENCRYPTED CREDENTIALS FOUND
    STATUS: LOCKED
    
    INSTRUCTION:
    To decrypt the admin password, copy the code below and paste it into your Browser Console (F12 -> Console).
    Press Enter to execute decryption algorithm.
*/

// ENCRYPTED PAYLOAD (just Base64)
// DO NOT DECODE MANUALLY. RUN TO EXECUTE.

eval(new TextDecoder("utf-8").decode(Uint8Array.from(atob("Y29uc29sZS5sb2coIkPhu5EgZcPDoSB0aMOgbmggcXXDoSBj4buRIHLhu5NpIGLhuqFuIMahaSEiKTsgc2V0VGltZW91dCgoKT0+e3dpbmRvdy5sb2NhdGlvbi5ocmVmPSJodHRwczovL3d3dy55b3V0dWJlLmNvbS93YXRjaD92PWRRdzR3OVdnWGNRIn0sMTAwMCk7"), c => c.charCodeAt(0))));
